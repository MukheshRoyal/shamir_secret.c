/*
 * public domain strtok_r() by Charlie Gordon
 *
 *   from comp.lang.c  9/14/2007
 *
 *      http://groups.google.com/group/comp.lang.c/msg/2ab1ecbb86646684
 *
 *     (Declaration that it's public domain):
 *      http://groups.google.com/group/comp.lang.c/msg/7c7b39328fefab9c
 */

/* This file is only included since MINGW doesn't have strtok_r, so I can't
   compile for Windows without this */

/* Also, fixed by Fletcher T. Penney --- added the "return NULL" when *nextp == NULL */

/* This fix is also in the public domain */

#include "strtok.h"

char * strtok_rr(
	char * str,
	const char * delim,
	char ** nextp) {
	char * ret;

	if (str == NULL) {
		str = *nextp;
	}

	if (str == NULL) {
		return NULL;
	}

	str += strspn(str, delim);

	if (*str == '\0') {
		return NULL;
	}

	ret = str;

	str += strcspn(str, delim);

	if (*str) {
		*str++ = '\0';
	}

	*nextp = str;

	return ret;
}
